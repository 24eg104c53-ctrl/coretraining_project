//============================================================================
// traffic_light_controller_tb.v  - self-checking testbench
//============================================================================
`timescale 1ns/1ps

module traffic_light_controller_tb;

    localparam GREEN_TIME  = 5;
    localparam YELLOW_TIME = 2;
    localparam CYCLE_LEN   = 2*GREEN_TIME + 2*YELLOW_TIME;
    localparam NUM_CYCLES  = 4;               // full traffic cycles to observe

    reg  clk;
    reg  rst;
    wire ns_red, ns_yellow, ns_green;
    wire ew_red, ew_yellow, ew_green;

    traffic_light_controller dut (
        .clk(clk), .rst(rst),
        .ns_red(ns_red), .ns_yellow(ns_yellow), .ns_green(ns_green),
        .ew_red(ew_red), .ew_yellow(ew_yellow), .ew_green(ew_green)
    );

    // 10 ns clock
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // ------------------------------------------------------------------
    // Bookkeeping
    // ------------------------------------------------------------------
    integer total_tests, passed_tests, failed_tests;
    integer safety_fail, timing_fail, fsm_fail;
    integer cyc;
    integer cur_code, prev_code, run_len, exp_len;
    reg     check_en;

    reg [8*9:1] sname;
    reg [8*6:1] nsc, ewc;

    // category: 0 = safety, 1 = timing, 2 = fsm
    task chk(input cond, input integer cat);
        begin
            total_tests = total_tests + 1;
            if (cond) passed_tests = passed_tests + 1;
            else begin
                failed_tests = failed_tests + 1;
                case (cat)
                    0: safety_fail = safety_fail + 1;
                    1: timing_fail = timing_fail + 1;
                    default: fsm_fail = fsm_fail + 1;
                endcase
                $display("  ** FAIL (cat %0d) at time %0t, cycle %0d", cat, $time, cyc);
            end
        end
    endtask

    // ------------------------------------------------------------------
    // Checker: samples outputs on every falling clock edge
    // ------------------------------------------------------------------
    always @(negedge clk) begin
        if (check_en) begin
            cyc = cyc + 1;

            // decode state from the outputs only
            if      (ns_green  && ew_red   && !ns_yellow && !ns_red && !ew_yellow && !ew_green) cur_code = 0;
            else if (ns_yellow && ew_red   && !ns_green  && !ns_red && !ew_yellow && !ew_green) cur_code = 1;
            else if (ew_green  && ns_red   && !ew_yellow && !ew_red && !ns_yellow && !ns_green) cur_code = 2;
            else if (ew_yellow && ns_red   && !ew_green  && !ew_red && !ns_yellow && !ns_green) cur_code = 3;
            else                                                                                 cur_code = -1;

            case (cur_code)
                0: begin sname = "NS_GREEN "; end
                1: begin sname = "NS_YELLOW"; end
                2: begin sname = "EW_GREEN "; end
                3: begin sname = "EW_YELLOW"; end
                default: begin sname = "ILLEGAL  "; end
            endcase
            nsc = ns_green ? "GREEN " : ns_yellow ? "YELLOW" : ns_red ? "RED   " : "??????";
            ewc = ew_green ? "GREEN " : ew_yellow ? "YELLOW" : ew_red ? "RED   " : "??????";
            $display("%s NS=%s EW=%s   (t=%0t, cycle %0d)", sname, nsc, ewc, $time, cyc);

            // ---- safety checks ----
            chk(!(ns_green && ew_green),            0);   // never both green
            chk(!ns_green  || ew_red,               0);   // NS green  -> EW red
            chk(!ns_yellow || ew_red,               0);   // NS yellow -> EW red
            chk(!ew_green  || ns_red,               0);   // EW green  -> NS red
            chk(!ew_yellow || ns_red,               0);   // EW yellow -> NS red
            chk(((ns_red + ns_yellow + ns_green) == 1) &&
                ((ew_red + ew_yellow + ew_green) == 1), 0); // one light per road

            // ---- FSM checks ----
            chk(cur_code != -1,                     2);   // legal state

            if (prev_code == -1) begin
                chk(cur_code == 0, 2);                    // first state after reset
                run_len = 1;
            end else if (cur_code != prev_code) begin
                // transition: verify duration of the state just left + order
                exp_len = (prev_code == 0 || prev_code == 2) ? GREEN_TIME : YELLOW_TIME;
                chk(run_len == exp_len,                 1);
                chk(cur_code == ((prev_code + 1) % 4),  2);
                run_len = 1;
            end else begin
                run_len = run_len + 1;
                exp_len = (cur_code == 0 || cur_code == 2) ? GREEN_TIME : YELLOW_TIME;
                chk(run_len <= exp_len,                 1);
            end
            prev_code = cur_code;
        end
    end

    // ------------------------------------------------------------------
    // Stimulus
    // ------------------------------------------------------------------
    initial begin
        $dumpfile("traffic_light_controller_gls.vcd");
        $dumpvars(0, traffic_light_controller_tb);

        total_tests = 0; passed_tests = 0; failed_tests = 0;
        safety_fail = 0; timing_fail = 0; fsm_fail = 0;
        cyc = 0; prev_code = -1; run_len = 0; cur_code = -1; exp_len = 0;
        check_en = 1'b0;
        rst = 1'b1;

        // ---- initial reset ----
        repeat (3) @(posedge clk);
        @(negedge clk);
        $display("RESET        NS=%s EW=%s", ns_green ? "GREEN " : "other ",
                                             ew_red   ? "RED   " : "other ");
        chk(ns_green && ew_red && !ns_yellow && !ns_red && !ew_yellow && !ew_green, 2);
        @(posedge clk);
        #1 rst = 1'b0;
        check_en = 1'b1;

        // ---- run several complete traffic cycles ----
        repeat (NUM_CYCLES*CYCLE_LEN) @(posedge clk);

        // ---- mid-operation reset: apply while in EW_GREEN ----
        while (cur_code != 2) @(posedge clk);
        #1 check_en = 1'b0;
        rst = 1'b1;
        $display("--- reset applied during EW_GREEN ---");
        @(posedge clk);
        @(negedge clk);
        $display("RESET        NS=%s EW=%s", ns_green ? "GREEN " : "other ",
                                             ew_red   ? "RED   " : "other ");
        chk(ns_green && ew_red && !ns_yellow && !ns_red && !ew_yellow && !ew_green, 2);
        @(posedge clk);
        #1 rst = 1'b0;
        prev_code = -1; run_len = 0;
        check_en = 1'b1;

        // ---- one more full cycle after the reset ----
        repeat (CYCLE_LEN) @(posedge clk);
        @(negedge clk);
        #1 check_en = 1'b0;

        // ---- summary ----
        $display("");
        $display("SAFETY CHECK: %s", (safety_fail == 0) ? "PASS" : "FAIL");
        $display("TIMING CHECK: %s", (timing_fail == 0) ? "PASS" : "FAIL");
        $display("FSM CHECK: %s",    (fsm_fail    == 0) ? "PASS" : "FAIL");
        $display("");
        $display("TOTAL TESTS : %0d", total_tests);
        $display("PASSED      : %0d", passed_tests);
        $display("FAILED      : %0d", failed_tests);
        $display("");
        if (failed_tests == 0) $display("TESTBENCH PASSED");
        else                   $display("TESTBENCH FAILED");
        $finish;
    end

    // watchdog
    initial begin
        #200000;
        $display("TIMEOUT - TESTBENCH FAILED");
        $finish;
    end

endmodule
