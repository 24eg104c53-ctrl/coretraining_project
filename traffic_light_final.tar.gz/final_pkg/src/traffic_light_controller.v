//============================================================================
// traffic_light_controller.v
// 2-road (NS / EW) traffic light controller - Moore FSM + state timer
//
// Reset : SYNCHRONOUS, ACTIVE-HIGH (rst sampled on rising edge of clk)
// States: S0 NS_GREEN -> S1 NS_YELLOW -> S2 EW_GREEN -> S3 EW_YELLOW -> S0
// Timing: GREEN_TIME / YELLOW_TIME = number of clock cycles spent in state
//         (both must be >= 1)
//============================================================================
`timescale 1ns/1ps

module traffic_light_controller #(
    parameter GREEN_TIME  = 5,   // clock cycles in NS_GREEN and EW_GREEN
    parameter YELLOW_TIME = 2    // clock cycles in NS_YELLOW and EW_YELLOW
)(
    input  wire clk,
    input  wire rst,             // synchronous, active-high

    output wire ns_red,
    output wire ns_yellow,
    output wire ns_green,
    output wire ew_red,
    output wire ew_yellow,
    output wire ew_green
);

    // ------------------------------------------------------------------
    // State encoding (binary, 2 bits)
    // ------------------------------------------------------------------
    localparam [1:0] S0_NS_GREEN  = 2'b00,
                     S1_NS_YELLOW = 2'b01,
                     S2_EW_GREEN  = 2'b10,
                     S3_EW_YELLOW = 2'b11;

    // ------------------------------------------------------------------
    // Counter width: must hold 0 .. (max(GREEN,YELLOW) - 1)
    // ------------------------------------------------------------------
    localparam MAX_TIME = (GREEN_TIME > YELLOW_TIME) ? GREEN_TIME : YELLOW_TIME;
    localparam CNT_W    = (MAX_TIME > 2) ? $clog2(MAX_TIME) : 1;

    reg [1:0]       state, next_state;
    reg [CNT_W-1:0] cnt;

    // ------------------------------------------------------------------
    // Timer logic: terminal count for the current state
    // ------------------------------------------------------------------
    wire state_is_green = ~state[0];                 // S0 and S2
    wire [CNT_W-1:0] last_count =
        state_is_green ? (GREEN_TIME  - 1) : (YELLOW_TIME - 1);
    wire timer_done = (cnt == last_count);

    // ------------------------------------------------------------------
    // Next-state (combinational)
    // ------------------------------------------------------------------
    always @(*) begin
        next_state = state;
        if (timer_done) begin
            case (state)
                S0_NS_GREEN  : next_state = S1_NS_YELLOW;
                S1_NS_YELLOW : next_state = S2_EW_GREEN;
                S2_EW_GREEN  : next_state = S3_EW_YELLOW;
                S3_EW_YELLOW : next_state = S0_NS_GREEN;
                default      : next_state = S0_NS_GREEN;
            endcase
        end
    end

    // ------------------------------------------------------------------
    // State register + counter (synchronous reset)
    // ------------------------------------------------------------------
    always @(posedge clk) begin
        if (rst) begin
            state <= S0_NS_GREEN;
            cnt   <= {CNT_W{1'b0}};
        end else begin
            state <= next_state;
            if (timer_done)
                cnt <= {CNT_W{1'b0}};
            else
                cnt <= cnt + 1'b1;
        end
    end

    // ------------------------------------------------------------------
    // Output logic (Moore: depends on state only)
    // Each light is a direct decode of ONE state, so NS green (S0) and
    // EW green (S2) can never be 1 at the same time.
    // ------------------------------------------------------------------
    assign ns_green  = (state == S0_NS_GREEN);
    assign ns_yellow = (state == S1_NS_YELLOW);
    assign ns_red    = (state == S2_EW_GREEN) | (state == S3_EW_YELLOW);

    assign ew_green  = (state == S2_EW_GREEN);
    assign ew_yellow = (state == S3_EW_YELLOW);
    assign ew_red    = (state == S0_NS_GREEN) | (state == S1_NS_YELLOW);

endmodule
